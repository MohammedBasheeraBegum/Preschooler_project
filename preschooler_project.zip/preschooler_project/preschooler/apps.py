from django.apps import AppConfig


class PreschoolerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'preschooler'
