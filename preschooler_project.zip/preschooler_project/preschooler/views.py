from django.shortcuts import render
from django.http import HttpResponse
import csv
from gtts import gTTS
import os
import random

# Create your views here.
global ch

def button(request):
    return render(request, 'hello.html')

def say_hello(request):
    ch = 'a'  # Default value for ch
    abtn = request.POST.get('A btn')
    bbtn = request.POST.get('B btn')
    cbtn = request.POST.get('C btn')
    dbtn = request.POST.get('D btn')
    ebtn = request.POST.get('E btn')
    fbtn = request.POST.get('F btn')
    gbtn = request.POST.get('G btn')
    hbtn = request.POST.get('H btn')
    ibtn = request.POST.get('I btn')
    jbtn = request.POST.get('J btn')
    kbtn = request.POST.get('K btn')
    lbtn = request.POST.get('L btn')
    mbtn = request.POST.get('M btn')
    nbtn = request.POST.get('N btn')
    obtn = request.POST.get('O btn')
    pbtn = request.POST.get('P btn')
    qbtn = request.POST.get('Q btn')
    rbtn = request.POST.get('R btn')
    sbtn = request.POST.get('S btn')
    tbtn = request.POST.get('T btn')
    ubtn = request.POST.get('U btn')
    vbtn = request.POST.get('V btn')
    wbtn = request.POST.get('W btn')
    xbtn = request.POST.get('X btn')
    ybtn = request.POST.get('Y btn')
    zbtn = request.POST.get('Z btn')

    if abtn:
        ch = 'a'
    if bbtn:
        ch = 'b'
    if cbtn:
        ch = 'c'
    if dbtn:
        ch = 'd'
    if ebtn:
        ch = 'e'
    if fbtn:
        ch = 'f'
    if gbtn:
        ch = 'g'
    if hbtn:
        ch = 'h'
    if ibtn:
        ch = 'i'
    if jbtn:
        ch = 'j'
    if kbtn:
        ch = 'k'
    if lbtn:
        ch = 'l'
    if mbtn:
        ch = 'm'
    if nbtn:
        ch = 'n'
    if obtn:
        ch = 'o'
    if pbtn:
        ch = 'p'
    if qbtn:
        ch = 'q'
    if rbtn:
        ch = 'r'
    if sbtn:
        ch = 's'
    if tbtn:
        ch = 't'
    if ubtn:
        ch = 'u'
    if vbtn:
        ch = 'v'
    if wbtn:
        ch = 'w'
    if xbtn:
        ch = 'x'
    if ybtn:
        ch = 'y'
    if zbtn:
        ch = 'z'

    with open("C:\\Users\\LENOVO\\Desktop\\preschooler_project\\preschooler\\data.csv") as fd:
        reader = csv.reader(fd)
        interestingrows = [row for row in reader if row and row[0] == ch]
        if not interestingrows:
            return render(request, 'hello.html', {'data': 'No data available for the selected character.'})
        r = random.randint(0, len(interestingrows) - 1)
        mytext = interestingrows[r][0] + " for " + interestingrows[r][1] + " which means " + interestingrows[r][2]
        language = "en"
        myObjj = gTTS(text=mytext, lang=language, slow=False)
        myObjj.save("text.mp3")
        # print(mytext)
        os.system("start text.mp3")  # This line might need to be replaced
    return render(request, 'hello.html', {'data': mytext})
