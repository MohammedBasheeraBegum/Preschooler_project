from django.urls import path
from preschooler.views import say_hello
from preschooler.views import button

urlpatterns = [
    path('preschooler/', say_hello, name='preschooler'),
     path('script/', button, name='script'),
]
